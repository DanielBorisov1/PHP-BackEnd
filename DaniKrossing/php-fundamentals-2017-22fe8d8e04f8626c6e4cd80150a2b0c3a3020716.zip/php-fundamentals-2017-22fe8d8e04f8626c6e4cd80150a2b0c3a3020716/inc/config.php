<?php

const USER_NAME = 'admin@admin.com';
const PASSWORD = '1234';