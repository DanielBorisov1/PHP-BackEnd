<!DOCTYPE html>
<html lang="en">
<head>

    <title>Hello, World</title>
</head>
<body>
    <h1>This is the Title</h1>
    <?php 
    
    $name = 'Jeremy';

    echo "Hello, $name";
    
    ?>
    
</body>
</html>