<?php

class Term {
    function __construct($term, $definition) {
        $this->term = $term;
        $this->definition = $definition;
    }
}
