<?php

const CONFIG = [
    'data_file' => APP_PATH . 'data.json',
    'users' => [
        'admin@admin.com' => '1234'
    ]
];