<?php


define('APP_PATH', dirname(__FILE__) . '/../');

require('config.php');
require('functions.php');
require('data/file_functions.php');