<?php

const CONFIG = [
    'data_file' => 'data.json',
    'users' => [
        'admin@admin.com' => '1234'
    ]
];