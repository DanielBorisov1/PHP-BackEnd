<?php

require('../app/app.php');



view('admin/index', get_terms());