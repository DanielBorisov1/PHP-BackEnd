<?php


define('APP_PATH', dirname(__FILE__) . '/../');


require('functions.php');
require('data/filedataprovider.class.php');
require('config.php');