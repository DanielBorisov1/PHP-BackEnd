<?php

require('config.php');
require('functions.php');
require('data/file_functions.php');